#!groovy
/**
 * 
 * 
 * 
 * @author Pedro Daniel Valero Rueda <pedro.valero@iteraprocess.com>
 * @version 1.0
 * @param 
 * @return null
 * @exception 
 * @see 
 */
import groovy.json.JsonOutput
def data
def call() {
  node('master'){
    parsedJson = jiraIssueInfo()
    setRepoInfo(parsedJson)
  }
}

def setRepoInfo(Map parsedJson){
  def repos = []
  switch(env.ENV){
    case 'develop':
      parsedJson.detail.repositories.each{data ->
        console(type:'log',msg: "Repositorios versionados: " + data.size())
        data.each{ inf ->
          repos << processDev(inf)
        }
      }
      repos = sortRepo(repos)
      break
    default:
      if(!parsedJson.detail){
        console(type:'error',msg:'BITBUCKET Verifique la informaci\u00f3n de versionamiento relacionada al issue')
      }
      if(parsedJson.detail.branches[0].size() > 0 && env.ENV != 'drs' && !env.RLLBCK){
        println "Ramas asociadas al registro:\n" + JsonOutput.prettyPrint(JsonOutput.toJson(parsedJson.detail.branches))
        console(type:'error',msg:'BITBUCKET Hay data en branch no integrada. complete el pull request correspondiente')
      }
      data = parsedJson.detail[0].pullRequests
      repos = processQa()
      break
  }
  env["REPOS_INFO"] = JsonOutput.toJson(repos)
  println JsonOutput.prettyPrint(env["REPOS_INFO"])
}

def processDev(Map inf){
  projName = jobGetProjName(inf.url)
  repoName = inf.name
  bitbucketSetBranches(projName, repoName)

  def time = '0000-00-00T00:00:00.000-0000'
  def df = "yyyy-MM-dd'T'HH:mm:ss.S"
  commId = ""
  commAu = ""
  inf.commits.each{ commit -> 
    def dateTime1 = new Date().parse(df, commit.authorTimestamp)
    def dateTime2 = new Date().parse(df, time)
    if(dateTime1 > dateTime2){
      time = commit.authorTimestamp
      commId = commit.id.take(11)
      commAu = commit.author.name
    }
  }
  tech = getInfoFromRepo(proj:projName, repo: repoName, prop: "global.tech", commit: commId, path: '.jenkins.yml')
  dflTech = null
  if(!tech){
    console(type: 'error', msg: "CONFIG Recuerdas que se había informado que era necesario colocar la propiedad 'global.tech' en el archivo '.jenkins.yml' que se encuentra en la ruta inicial del proyecto?, pues bueno a partir de ahora si va a ser obligatorio colocarlo alli, pero no te afanes para los proyectos de qa, demo y prod en curso aun no van a fallar")
  }
  tech = tech.toUpperCase()

  language = getInfoFromRepo(proj:projName, repo: repoName, prop: "global.language", commit: commId, path: '.jenkins.yml')
  if(!language){
    console(type:'error',msg:"CONFIG no existe la llave 'global.language' en el archivo .jenkins.yml del repositorio ${projName}/${repoName}")
  }
  language = language.toUpperCase()
  env["DEPLOY_${tech}"] = "TRUE"
  def lRepo = [:]
  lRepo.proj = projName
  lRepo.name = repoName
  lRepo.commId = commId
  lRepo.commAuthor = commAu
  lRepo.language = language
  order = getInfoFromRepo(proj:projName, repo: repoName, prop: "global.order", commit: commId, path: '.jenkins.yml')
  order = order ? order.toInteger() : 99
  return ["${tech}":lRepo, order: order]
}

def processQa(){
  toProcess = [:]
  def df = "yyyy-MM-dd'T'HH:mm:ss.S"
  console(type:'log',msg: "Pullrequest generados: " + data.size())
  if(!data.size()){
    console(type:'error', msg:'BITBUCKET No hay pull request generados')
  }
  /*if(['drs'].contains(env.ENV)){
    println "status: " + jiraGetAttr('status').name
    //jira field for jenkins deploy on...
    //demo: customfield_25102
    //prod: customfield_25101
    //qa: customfield_25103
    //drs: customfield_26002
    println "jenkinsDemo:" + jiraGetAttr('customfield_25102').value
  }*/
  data.each{ pR ->
    if(pR.status != "MERGED"){
      return 
    }
    projName = jobGetProjName(pR.source.repository.url)
    repoName = pR.source.repository.name
    bitbucketSetBranches(projName, repoName)

    branch = env["branch${env.ENV.toUpperCase()}"]
    destBranch = pR.destination.branch

    if(destBranch != branch){
      return
    }
    cKey = projName + "-" + repoName
    if(toProcess[cKey]){
      def dateTime1 = new Date().parse(df, pR.lastUpdate)
      def dateTime2 = new Date().parse(df, toProcess[cKey].lastUpdate)
      processPR = false
      if(env.RLLBCK == 'true'){
        if(env.RLLBCK_TYPE == 'Ultimo' && dateTime1 > dateTime2){
          processPR = true
        }else if(env.RLLBCK_TYPE == 'Todos' && dateTime1 < dateTime2){
          processPR = true
        }
      }else{
        if(dateTime1 > dateTime2){
          processPR = true
        }
      }
      if(processPR){
        toProcess[cKey].commAuthor = pR.author.name
        toProcess[cKey].lastUpdate = pR.lastUpdate
        bbCommId = bitBucketCommId(projName, repoName, pR.id)
        if(env.ENV == 'drs'){
          toProcess[cKey] << [fromCommId: bbCommId]
        }else if(env.ENV != 'qa'){
          fromCommit = bitBucketCommId(projName, repoName, pR.id, true)
          toProcess[cKey] << [fromCommId: fromCommit]
        }
        toProcess[cKey].commId = bbCommId
      }
    }else{
      toProcess[cKey] = [:]
      toProcess[cKey].proj = projName
      toProcess[cKey].name = repoName
      toProcess[cKey].commAuthor = pR.author.name
      toProcess[cKey].lastUpdate = pR.lastUpdate
      bbCommId = bitBucketCommId(projName, repoName, pR.id)
      toProcess[cKey].commId = bbCommId
      if(env.ENV == 'drs'){
          toProcess[cKey] << [fromCommId: bbCommId]
      }else if(env.ENV != 'qa'){
        fromCommit = bitBucketCommId(projName, repoName, pR.id, true)
        toProcess[cKey].fromCommId = fromCommit
      }
      tech = getInfoFromRepo(proj:projName, repo: repoName, prop: "global.tech", commit: bbCommId, path: '.jenkins.yml')
      if(!tech){
        console(type:'warning',msg:"CONFIG no existe la llave 'global.tech' en el archivo .jenkins.yml del repositorio ${projName}/${repoName}")
        at = (env.JOB_NAME.contains('TEST_PPL'))?'test':'master'
        dflTech = getInfoFromRepo(proj:"SCP", repo: "JNKS_PPLNS", prop: "${repoName.toUpperCase()}.TECH", commit: at, path: "REPO-INFO/${projName}")
        if(!dflTech){
          console(type:'error',msg:"CONFIG no existe la llave '${repoName}.TECH' en el archivo REPO-INFO/${projName} del repositorio SCP/JNKS_PPLNS")
        }
        tech = dflTech.split("-")[0]

      }
      tech = tech.toUpperCase()

      language = getInfoFromRepo(proj:projName, repo: repoName, prop: "global.language", commit: bbCommId, path: '.jenkins.yml')
      if(!language){
        if(!dflTech){
          console(type:'warning',msg:"CONFIG no existe la llave 'global.language' en el archivo .jenkins.yml del repositorio ${projName}/${repoName}")
        }else{
          language = dflTech.split("-")[1]
        }
      }
      language = language.toUpperCase()

      toProcess[cKey].tech = tech
      toProcess[cKey].language = language
    }
  }
  def repos = []
  toProcess.each{ proc ->
    if(proc.value.tech == 'LIBRARIES'){
      return
    }
    env["DEPLOY_${proc.value.tech}"] = "TRUE"
    jiraComm("JENKINS: Preparando despliegue de '${proc.value.proj}/${proc.value.name}' de tipo '${proc.value.tech}'")
    def lRepo = [:]
    lRepo.proj = proc.value.proj
    lRepo.name = proc.value.name
    lRepo.commId = proc.value.commId
    lRepo.commAuthor = proc.value.commAuthor
    lRepo.language = proc.value.language
    if(env.ENV != 'qa'){
      lRepo.fromCommit = proc.value.fromCommId
    }
    order = getInfoFromRepo(proj:lRepo.proj, repo: lRepo.name, prop: "global.order", commit: lRepo.commId, path: '.jenkins.yml')
    order = order ? order.toInteger() : 99
    repos << [order: order, "${proc.value.tech}":lRepo]
  }
  repos = sortRepo(repos)
  return repos
}

@NonCPS
def sortRepo(repos){
    return repos.sort{it.order}
}